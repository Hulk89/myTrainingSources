#!/bin/sh
./cpUrl.sh
echo "#Open Random URL\nexport PATH=$PATH:$PWD;" >> ~/.bash_profile
