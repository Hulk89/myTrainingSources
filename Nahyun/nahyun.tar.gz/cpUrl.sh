#!/bin/sh
cp url.list ~/
