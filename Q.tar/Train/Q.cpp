#include <Q.h>
#include <stdlib.h>

bool Queue::isEmpty()
{
    if ( mHead == NULL )
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

void Queue::initializeQueue()
{
    mHead = NULL;
    mTail = NULL;

    return;
}

void Queue::enqueue( int aData )
{
    Node* sNode = NULL;

    /* malloc and set a Node */
    sNode        = (Node*)malloc(sizeof(Node));
    sNode->mData = aData;
    sNode->mNext = NULL;

    if ( mHead == NULL )
    {
        mHead = sNode;
        mTail = sNode;
    }
    else
    {
        mTail->mNext = sNode;
        mTail = sNode;
    }
    
    return;
}
bool Queue::dequeue(int * aData)
{
    Node* sNode = NULL;

    if ( isEmpty() != 1 )
    {
        sNode = mHead;
        mHead = mHead->mNext;
        
        *aData = sNode->mData;
        free(sNode);

        return 1;
    }
    else
    {
        return 0;
    }
}
