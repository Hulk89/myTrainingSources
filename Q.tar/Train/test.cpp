#include <iostream>
#include <Q.h>

using namespace::std;

int main()
{
    Queue  sQ;

    int sArr[100];
    int sCopyArr[100];
    int i;
    
    for ( i = 0 ; i < 100 ; i++ )
    {
        sArr[i] = i;
    }
    for ( i = 0 ; i < 100 ; i++ )
    {
        sQ.enqueue(sArr[i]);
    }
    for ( i = 0 ; i < 100 ; i++ )
    {
        sQ.dequeue(&sCopyArr[i]);
    }
    for ( i = 0 ; i < 100 ; i++ )
    {
        cout << sCopyArr[i] << " ";
    }
    cout << endl;

    return 0;
}
