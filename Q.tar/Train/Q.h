
typedef struct Node Node;

typedef struct Node
{
    int      mData;
    Node   * mNext;
} Node;


class Queue
{
private:
    Node * mHead;
    Node * mTail;

public:
    void initializeQueue();
    bool isEmpty();
    void enqueue( int aData );
    bool dequeue( int *aData );
};



